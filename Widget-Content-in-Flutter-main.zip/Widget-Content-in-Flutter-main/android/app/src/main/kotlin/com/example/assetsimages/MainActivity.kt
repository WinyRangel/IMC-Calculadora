package com.example.assetsimages

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
